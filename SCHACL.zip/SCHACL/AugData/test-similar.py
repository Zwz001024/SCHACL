import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity, euclidean_distances, manhattan_distances
from scipy.stats import spearmanr
from scipy.spatial.distance import hamming


# 定义余弦相似度函数
def similarity(text1, text2, text3):
    # 使用TF-IDF向量化器
    vectorizer = TfidfVectorizer()
    # 将文本转换为TF-IDF向量
    tfidf_matrix = vectorizer.fit_transform([text1, text2, text3])

    # 计算第一个文本和第二个文本的余弦相似度
    cosine_sim_text1_text2 = cosine_similarity(tfidf_matrix[0:1], tfidf_matrix[1:2])
    print("Similarity between text1 and text2:", cosine_sim_text1_text2[0][0])

    # 计算text1和text3的余弦相似度
    cosine_sim_text1_text3 = cosine_similarity(tfidf_matrix[0:1], tfidf_matrix[2:3])
    print("Similarity between text1 and text3:", cosine_sim_text1_text3[0][0])


# 定义斯皮尔曼函数
def calculate_spearman_correlation(text1, text2, text3):
    # 使用TfidfVectorizer将文本转化为特征向量
    vectorizer = TfidfVectorizer()
    vectors = vectorizer.fit_transform([text1, text2, text3]).toarray()

    # 计算text1和text2的斯皮尔曼相关系数
    correlation_text1_text2, _ = spearmanr(vectors[0], vectors[1])
    print(f"Spearman correlation between text1 and text2: {correlation_text1_text2}")

    # 计算text1和text3的斯皮尔曼相关系数
    correlation_text1_text3, _ = spearmanr(vectors[0], vectors[2])
    print(f"Spearman correlation between text1 and text3: {correlation_text1_text3}")


# 定义距离评价函数
def calculate_text_similarity(text1, text2, text3):
    # 使用TfidfVectorizer将文本转换为TF-IDF特征向量
    vectorizer = TfidfVectorizer()
    vectors = vectorizer.fit_transform([text1, text2, text3]).toarray()

    # 计算欧式距离
    euclidean_dist_text1_text2 = euclidean_distances([vectors[0]], [vectors[1]])[0][0]
    euclidean_dist_text1_text3 = euclidean_distances([vectors[0]], [vectors[2]])[0][0]

    # 计算曼哈顿距离
    manhattan_dist_text1_text2 = manhattan_distances([vectors[0]], [vectors[1]])[0][0]
    manhattan_dist_text1_text3 = manhattan_distances([vectors[0]], [vectors[2]])[0][0]

    # 计算汉明距离（先将向量转化为二进制形式）
    vector1_binary = [1 if x > 0 else 0 for x in vectors[0]]
    vector2_binary = [1 if x > 0 else 0 for x in vectors[1]]
    vector3_binary = [1 if x > 0 else 0 for x in vectors[2]]

    hamming_dist_text1_text2 = hamming(vector1_binary, vector2_binary)
    hamming_dist_text1_text3 = hamming(vector1_binary, vector3_binary)

    print("Distance metrics between text1 and text2:")
    print(f"Euclidean Distance: {euclidean_dist_text1_text2}")
    print(f"Manhattan Distance: {manhattan_dist_text1_text2}")
    print(f"Hamming Distance: {hamming_dist_text1_text2}")

    print("Distance metrics between text1 and text3:")
    print(f"Euclidean Distance: {euclidean_dist_text1_text3}")
    print(f"Manhattan Distance: {manhattan_dist_text1_text3}")
    print(f"Hamming Distance: {hamming_dist_text1_text3}")


# 主函数
if __name__ == '__main__':
    text1 = "bhp billiton approves chile copper project western australia iron lt gt lt gt sydney bhp billiton approved copper project northern chile costing dollars expansion iron ore operations western australia"
    text2 = "bhp billiton approves chile chile copper project western western australia iron lt gt lt gt sydney bhp bhp billiton approved copper project northern chile costing dollars expansion iron ore operations western australia"
    text3 = "bhp bhp billiton approves chile copper project project western australia iron lt gt lt gt sydney bhp billiton approved copper copper project northern chile costing dollars dollars expansion iron ore operations western australia"

    print("text1为原始数据集，text2和text3为同一数据增强方法进行的两次结果")
    print("Cosine Similarity:")
    similarity(text1, text2, text3)

    print("\nSpearman Correlation:")
    calculate_spearman_correlation(text1, text2, text3)

    print("\nDistance Metrics:")
    calculate_text_similarity(text1, text2, text3)
