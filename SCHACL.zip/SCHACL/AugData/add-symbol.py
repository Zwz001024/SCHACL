import random
import string
import pandas as pd

def insert_punctuation(sequence):
    # 定义标点符号集合
    punctuations = {'.', ';', '?', ':', '!', ','}

    # 使用空格分词
    words = sequence.split()

    # 如果单词列表为空，则直接返回原序列
    if not words:
        return sequence

    # 计算插入标点符号的次数（范围在1到max_inserts之间）
    max_inserts = max(1, len(words) // 3)
    num_inserts = random.randint(1, max_inserts)

    # 初始化一个列表来存储处理后的单词
    modified_words = []

    # 遍历单词列表，并在随机位置插入标点符号
    for i, word in enumerate(words):
        modified_words.append(word)
        if i < len(words) - 1 and num_inserts > 0:
            # 决定是否在当前单词和下一个单词之间插入标点符号
            if random.random() < num_inserts / (len(words) - i):
                # 随机选择一个标点符号
                punctuation = random.choice(list(punctuations))
                modified_words.append(punctuation)
                num_inserts -= 1

    # 将处理后的单词列表转换回字符串，并用空格连接
    modified_sequence = ' '.join(modified_words)

    return modified_sequence

# 读取CSV文件
input_csv ="/23085405013/S-raw.csv"  # 输入文件路径
output_csv="/23085405013/S-raw-adds.csv"  # 输出文件路径

df = pd.read_csv(input_csv)

# 假设第二列的列名为 'text_column'
text_column = 'text'  # 修改为实际的列名

# 对第二列数据进行两次数据增强，并将其保存到第三列和第四列
df['augmented_text_1'] = df[text_column].apply(insert_punctuation)
df['augmented_text_2'] = df[text_column].apply(insert_punctuation)

# 保存到新的CSV文件
df.to_csv(output_csv, index=False)

print(f"增强后的数据已保存到 {output_csv}")
