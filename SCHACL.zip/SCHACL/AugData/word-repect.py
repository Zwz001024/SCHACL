import csv
import random
#这个是按照simcse中的机制进行设定的
# 定义重复率的超参数
dup_rate = 0.2  # 假设重复率为0.5

#
input_file = '/23085405013/Traw.csv'
output_file = '/23085405013/Traw-simcse2.csv'

with open(input_file, 'r', newline='', encoding='utf-8') as f:
    reader = csv.reader(f)
    data = list(reader)

# 对每行数据进行处理
processed_data = []

for row in data:
    if len(row) < 2:
        continue  # 跳过空行或格式不符合要求的行

    text = row[1]  # 获取第二列文本
    words = text.split()  # 分词

    N = len(words)  # 序列长度
    max_dup_len = max(1, int(dup_rate * N))  # 根据公式计算最大重复数量

    if max_dup_len == 0:
        continue  # 如果最大重复数量为0，跳过

    dup_len = random.randint(1, min(max_dup_len, N))  # 随机选择重复数量
    dup_set = random.sample(range(1, N + 1), dup_len)  # 随机选择需要重复的位置

    for idx in sorted(dup_set, reverse=True):
        words.insert(idx - 1, words[idx - 1])  # 根据dup_set重复单词

    augmented_text = ' '.join(words)  # 重新组合文本

    # 将处理后的数据添加到新的列表中

    row.append(augmented_text)  # 第三列保存第一次增强的结果
    processed_data.append(row)
# 将处理后的数据写入新的CSV文件
with open(output_file, 'w', newline='', encoding='utf-8') as f:
    writer = csv.writer(f)
    writer.writerows(processed_data)

print("数据增强完成，并保存到", output_file)

