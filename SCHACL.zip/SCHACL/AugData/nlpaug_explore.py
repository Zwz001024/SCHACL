import os
import time
import random
import argparse
import numpy as np
import pandas as pd

import torch
import nlpaug.augmenter.char as nac
import nlpaug.augmenter.word as naw
from nlpaug.util import Action

parser = argparse.ArgumentParser()
parser.add_argument('--dataset', type=str, default='T')
parser.add_argument('--augtype', type=str, default='charswap')
parser.add_argument('--aug_min', type=int, default=1) 
parser.add_argument('--aug_p', type=float, default=0.2)
parser.add_argument('--aug_max', type=int, default=10)
parser.add_argument('--gpuid', type=int, default=0)
args = parser.parse_args()


def set_global_random_seed(seed):
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    np.random.seed(seed)
    random.seed(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = True


def contextual_augment(data_source, data_target, textcol="text", aug_p=0.1, device1="cuda", device2="cuda"):
    ### contextual augmentation 
    print(f"\n-----transformer_augment-----\n")
    augmenter1 = naw.ContextualWordEmbsAug(
        model_path='/23085405013/sccl-main/sccl-main/bert1/roberta-base', action="substitute", aug_min=1, aug_p=aug_p, device=device1)
      #  model_path='/23085405013/sccl-main/sccl-main/bert1/distilbert-base-nli-stsb-mean-tokens', action="substitute", aug_min=1, aug_p=aug_p, device=device1)
    
    augmenter2 = naw.ContextualWordEmbsAug(
       model_path='/23085405013/sccl-main/sccl-main/bert1/bert-base-uncased', action="substitute", aug_min=1, aug_p=aug_p, device=device2)
      #  model_path='/23085405013/sccl-main/sccl-main/bert1/distilbert-base-nli-stsb-mean-tokens', action="substitute", aug_min=1, aug_p=aug_p, device=device1)
        
    train_data = pd.read_csv(data_source)
    train_text = train_data[textcol].fillna('.').astype(str).values
    print("train_text:", len(train_text), type(train_text[0]))

    auglist1, auglist2 = [], []
    for txt in train_text:
        atxt1 = augmenter1.augment(txt)
        atxt2 = augmenter2.augment(txt)
        auglist1.append(str(atxt1))
        auglist2.append(str(atxt2))
        
    train_data[textcol+"1"] = pd.Series(auglist1)
    train_data[textcol+"2"] = pd.Series(auglist2)
    train_data.to_csv(data_target, index=False)
    
    for o, a1, a2 in zip(train_text[:5], auglist1[:5], auglist2[:5]):
        print("-----Original Text: \n", o)
        print("-----Augmented Text1: \n", a1)
        print("-----Augmented Text2: \n", a2)


def word_deletion(data_source, data_target, textcol="text", aug_p=0.2):
    ### wordnet based data augmentation
    print(f"\n-----word_deletion-----\n")
    aug = naw.RandomWordAug(aug_min=1, aug_p=aug_p)
    
    train_data = pd.read_csv(data_source)
    train_text = train_data[textcol].fillna('.').astype(str).values
    print("train_text:", len(train_text), type(train_text[0]))

    augtxts1, augtxts2 = [], []
    for txt in train_text:
        atxt = aug.augment(txt, n=2, num_thread=1)
        augtxts1.append(str(atxt[0]))
        augtxts2.append(str(atxt[1]))
        
    train_data[textcol+"1"] = pd.Series(augtxts1)
    train_data[textcol+"2"] = pd.Series(augtxts2)
    train_data.to_csv(data_target, index=False)
    
    for o, a1, a2 in zip(train_text[:5], augtxts1[:5], augtxts2[:5]):
        print("-----Original Text: \n", o)
        print("-----Augmentation1: \n", a1)
        print("-----Augmentation2: \n", a2)
        
        
def randomchar_augment(data_source, data_target, textcol="text", aug_p=0.2, augstage="post"):
    ### wordnet based data augmentation
    print(f"\n*****random char aug: rate--{aug_p}, stage: {augstage}*****\n")
    aug = nac.RandomCharAug(action="swap", aug_char_p=aug_p, aug_word_p=aug_p)
    
    train_data = pd.read_csv(data_source)
    if augstage == "init":
        train_text = train_data[textcol].fillna('.').astype(str).values
        print("train_text:", len(train_text), type(train_text[0]))

        augtxts1, augtxts2 = [], []
        for txt in train_text:
            atxt = aug.augment(txt, n=2, num_thread=1)
            augtxts1.append(str(atxt[0]))
            augtxts2.append(str(atxt[1]))

        train_data[textcol+"1"] = pd.Series(augtxts1)
        train_data[textcol+"2"] = pd.Series(augtxts2)
        train_data.to_csv(data_target, index=False)

        for o, a1, a2 in zip(train_text[:5], augtxts1[:5], augtxts2[:5]):
            print("-----Original Text: \n", o)
            print("-----Augmentation1: \n", a1)
            print("-----Augmentation2: \n", a2)
    else:
        train_text1 = train_data[textcol+"1"].fillna('.').astype(str).values
        train_text2 = train_data[textcol+"2"].fillna('.').astype(str).values
        
        augtxts1, augtxts2 = [], []
        for txt1, txt2 in zip(train_text1, train_text2):
            atxt1 = aug.augment(txt1, n=1, num_thread=1)
            atxt2 = aug.augment(txt2, n=1, num_thread=1)
            augtxts1.append(str(atxt1))
            augtxts2.append(str(atxt2))

        train_data[textcol+"1"] = pd.Series(augtxts1)
        train_data[textcol+"2"] = pd.Series(augtxts2)
        train_data.to_csv(data_target, index=False)

        for o1, a1, o2, a2 in zip(train_text1[:2], augtxts1[:2], train_text2[:2], augtxts2[:2]):
            print("-----Original Text1: \n", o1)
            print("-----Augmentation1: \n", a1)
            print("-----Original Text2: \n", o2)
            print("-----Augmentation2: \n", a2)

def word_duplication(data_source, data_target, textcol="text", aug_p=0.2):
    """
    对文本进行数据增强，通过随机复制单词的方式进行增强。

    参数：
    - data_source: 输入数据的文件路径 (CSV)
    - data_target: 增强后数据的输出文件路径 (CSV)
    - textcol: 需要增强的文本列的名称 (默认为"text")
    - aug_p: 增强比率，表示需要复制的单词所占的比例 (默认为0.2)
    """
    print(f"\n-----word_duplication-----\n")

    # 读取数据
    train_data = pd.read_csv(data_source)
    train_text = train_data[textcol].fillna('.').astype(str).values
    print("train_text:", len(train_text), type(train_text[0]))

    # 存储增强后的文本
    augtxts1, augtxts2 = [], []

    for txt in train_text:
        # 对文本进行分词
        words = txt.split()
        N = len(words)

        # 根据增广比率aug_p来决定复制单词的数量
        num_to_dup = max(1, int(aug_p * N))  # 至少复制1个单词

        # 随机复制单词
        augtxt1 = words.copy()
        augtxt2 = words.copy()

        # 随机选择num_to_dup个位置进行复制
        dup_indices1 = random.sample(range(N), num_to_dup)
        dup_indices2 = random.sample(range(N), num_to_dup)

        # 对于选中的位置，插入相同的单词
        for idx in sorted(dup_indices1, reverse=True):
            augtxt1.insert(idx, words[idx])

        for idx in sorted(dup_indices2, reverse=True):
            augtxt2.insert(idx, words[idx])

        # 将增强后的文本保存为字符串
        augtxts1.append(' '.join(augtxt1))
        augtxts2.append(' '.join(augtxt2))

    # 将处理后的数据保存到CSV文件的第三列和第四列
    train_data[textcol + "1"] = pd.Series(augtxts1)
    train_data[textcol + "2"] = pd.Series(augtxts2)
    train_data.to_csv(data_target, index=False)

    # 打印前5条原始和增强后的文本进行对比
    for o, a1, a2 in zip(train_text[:5], augtxts1[:5], augtxts2[:5]):
        print("-----Original Text: \n", o)
        print("-----Augmentation1: \n", a1)
        print("-----Augmentation2: \n", a2)
        

def augment_files(datadir="./", targetdir="./", dataset="wiki1m_unique", aug_p=0.1, augtype="trans_subst"):
    set_global_random_seed(0)
    device1=torch.cuda.set_device(0)

    device2=torch.cuda.set_device(0)
    DataSource = os.path.join(datadir, dataset + ".csv")
    DataTarget = os.path.join(targetdir, '{}_{}_{}.csv'.format(dataset, augtype, int(aug_p*100)))

    if augtype == "word_deletion":
        augseq = word_deletion(DataSource, DataTarget, textcol="text", aug_p=aug_p)
    elif augtype == "word_duplication":
        augseq = word_duplication(DataSource, DataTarget, textcol="text", aug_p=aug_p)
    elif augtype == "trans_subst":
        augseq = contextual_augment(DataSource, DataTarget, textcol="text", aug_p=aug_p, device1=device1, device2=device2)
    elif augtype == "charswap":
        augseq = randomchar_augment(DataSource, DataTarget, textcol="text", aug_p=aug_p, augstage="post")
    else:
        print("Please specify AugType!!")



if __name__ == '__main__':
    
    datadir = "/23085405013/"
    targetdir = "/23085405013/"
    augment_files(datadir=datadir, targetdir=targetdir, dataset="TS_no-enhence", aug_p=0.1, augtype="trans_subst")
#     datasets = ["agnews", "searchsnippets", "stackoverflow", "biomedical", "googlenews_TS", "googlenews_T", "googlenews_S"]
    
#     for dataset in datasets:
#         augment_files(datadir=datadir, targetdir=targetdir, dataset=dataset, aug_p=0.1, augtype="trans_subst")
        # augment_files(datadir=datadir, targetdir=targetdir, dataset=dataset, aug_p=0.2, augtype="trans_subst")
    
    # for dataset in datasets:
    #     augment_files(datadir=datadir, targetdir=targetdir, dataset=dataset, aug_p=0.1, augtype="word_deletion")
    #     augment_files(datadir=datadir, targetdir=targetdir, dataset=dataset, aug_p=0.2, augtype="word_deletion")
    
   # datasets = ["agnews_trans_subst_20", "searchsnippets_trans_subst_20", "stackoverflow_trans_subst_20", "biomedical_trans_subst_20", "googlenews_TS_trans_subst_20", "googlenews_T_trans_subst_20", "googlenews_S_trans_subst_20"]

   # for dataset in datasets:
       # augment_files(datadir=datadir, targetdir=targetdir, dataset=dataset, aug_p=0.2, augtype="charswap")






