import pandas as pd
import nltk
from nltk import pos_tag
from nltk.tokenize import word_tokenize
import random
import nlpaug.augmenter.word as naw


nltk.download('punkt')
nltk.download('averaged_perceptron_tagger')


MANDATORY_DELETE_POS = ['RB', 'IN', 'DT', 'CC', 'PRP', 'PRP$', 'UH']  # 副词, 介词, 冠词, 连词, 代词, 感叹词

# 可选删除的词性及其对应的删除概率
OPTIONAL_DELETE_POS = {
    'NN': 0.05, 'NNS': 0.05, 'NNP': 0.05, 'NNPS': 0.05,  # 名词
    'VB': 0.05, 'VBD': 0.05, 'VBG': 0.05, 'VBN': 0.05, 'VBP': 0.05, 'VBZ': 0.05,  # 动词
    'JJ': 0.1, 'JJR': 0.1, 'JJS': 0.1  # 形容词
}



def delete_words_by_pos(text, aug_p=0.2):
    words = word_tokenize(text)
    pos_tags = pos_tag(words) 

    # 必定删除的词
    words_to_keep = [
        word for i, (word, pos) in enumerate(pos_tags)
        if pos not in MANDATORY_DELETE_POS
    ]

    # 随机删除可选的词
    for i, (word, pos) in enumerate(pos_tags):
        if pos in OPTIONAL_DELETE_POS:
            if random.random() < OPTIONAL_DELETE_POS[pos]:
                continue  # 删除这个词
        words_to_keep.append(word)

    return ' '.join(words_to_keep)


# 主函数
def word_deletion(data_source, data_target, textcol="text", aug_p=0.2):
    print(f"\n-----word_deletion-----\n")
    aug = naw.RandomWordAug(aug_min=1, aug_p=0.2)
    # 读取数据
    train_data = pd.read_csv(data_source)
    train_text = train_data[textcol].fillna('.').astype(str).values
    print("train_text:", len(train_text), type(train_text[0]))

    augtxts1, augtxts2 = [], []

    for txt in train_text:
        # 第一次随机删除
        atxt1 = delete_words_by_pos(txt, aug_p)
        # 第二次随机删除
        atxt2 = delete_words_by_pos(txt, aug_p)

        atxt = aug.augment(txt, n=2, num_thread=1)
        augtxts1.append(str(atxt[0]))
        augtxts2.append(str(atxt[1]))

    # 将处理结果保存到第三列和第四列
    train_data[textcol + "1"] = pd.Series(augtxts1)
    train_data[textcol + "2"] = pd.Series(augtxts2)
    train_data.to_csv(data_target, index=False)

    # 输出前5行的对比
    for o, a1, a2 in zip(train_text[:5], augtxts1[:5], augtxts2[:5]):
        print("-----Original Text: \n", o)
        print("-----Augmentation1: \n", a1)
        print("-----Augmentation2: \n", a2)


# 调用示例
# word_deletion('input.csv', 'output.csv', textcol='text', aug_p=0.2)

# 调用示例
word_deletion('/23085405013/searchraw.csv', '/23085405013/searchraw-pos0.1.csv', textcol='text', aug_p=0.2)


