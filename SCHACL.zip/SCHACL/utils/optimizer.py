"""
Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved

Author: Dejiao Zhang (dejiaoz@amazon.com)
Date: 02/26/2021
"""

import os
import torch 
from transformers import get_linear_schedule_with_warmup, BertModel, BertTokenizer, AutoModel, BertConfig,  AutoTokenizer, TFAutoModel
from transformers import  AutoConfig
from sentence_transformers import SentenceTransformer
from transformers.models.bert.modeling_bert import BertEmbeddings, BertEncoder, BertOnlyMLMHead
from transformers import DistilBertTokenizer, DistilBertModel
BERT_CLASS = {
    "distilbert": 'distilbert-base-uncased', 
}

SBERT_CLASS = {
    "distilbert": 'distilbert-base-nli-stsb-mean-tokens',
}


def get_optimizer(model, args):
    
    optimizer = torch.optim.Adam([
        {'params':model.bert.parameters()}, 
        {'params':model.contrast_head.parameters(), 'lr': args.lr*args.lr_scale},
        {'params':model.cluster_centers, 'lr': args.lr*args.lr_scale}
    ], lr=args.lr)
    
    print(optimizer)
    return optimizer 
    

def get_bert(args):
    
    if args.use_pretrain == "SBERT":
        model_path = "/23085405013/23085405013/distilbert-base-nli-stsb-mean-tokens"
       # model_path = "/23085405013/sccl-main/sccl-main/bert1/esimcse-bert-base-uncased"
       # model_path = "/23085405013/sccl-main/sccl-main/bert1/simcse"
        #tokenizer = BertTokenizer.from_pretrained(model_path)
       # config = BertConfig.from_pretrained(model_path)
       # model = BertModel.from_pretrained(model_path, config=config)
        tokenizer = AutoTokenizer.from_pretrained(model_path)
        model = AutoModel.from_pretrained(model_path)
        # bert_model = get_sbert(args)
       # tokenizer = bert_model[0].tokenizer
       # model = bert_model[0].auto_model
        print("..... loading Sentence-BERT !!!")
    else:
     #   tokenizer = DistilBertTokenizer.from_pretrained('distilbert-base-uncased')
      #  model = DistilBertModel.from_pretrained("distilbert-base-uncased")
        model_path = "/23085405013/sccl-main/sccl-main/bert"
       # bert = BertModel.from_pretrained(model_path)
      #  tokenizer = DistilBertTokenizer.from_pretrained(model_path)
     #   config = BertConfig.from_pretrained(model_path)
      #  model = DistilBertModel.from_pretrained(model_path, config=config)
      #  model = BertModel.from_pretrained(model_path,config=config)
        tokenizer = BertTokenizer.from_pretrained(model_path)
        config = BertConfig.from_pretrained(model_path)
        model = BertModel.from_pretrained(model_path, config=config)
        print("..... loading plain BERT !!!")
        """
        config = AutoConfig.from_pretrained(BERT_CLASS[args.bert])
        model = AutoModel.from_pretrained(BERT_CLASS[args.bert], config=config)
        tokenizer = AutoTokenizer.from_pretrained(BERT_CLASS[args.bert])"""

        
    return model, tokenizer


def get_sbert(args):
    sbert = SentenceTransformer(SBERT_CLASS[args.bert])
    return sbert








